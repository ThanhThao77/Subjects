<!DOCTYPE html>
<html>
<head>
  <title>Testing Installation</title>
</head>
<body>
  <h1><?php echo 'Welcome to PHP &amp; MySQL'?></h1>
  <h2><?php echo 'Your web server is working'; ?></h2>
  <?php phpinfo(); ?>
</body>
</html>