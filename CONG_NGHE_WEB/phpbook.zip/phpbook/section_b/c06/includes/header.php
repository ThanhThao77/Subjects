<!DOCTYPE html>
<html>
  <head>
    <title>Chapter 6 Examples</title>
    <link href="css/styles.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
    <meta charset="UTF-8">
  </head>
  <body>
    <div class="content">
      <div class="page">
        <header>
          <a href="index.php"><img src="img/logo.png" alt="Mountain Art Supplies" height="90"></a>
        </header>
        <section>