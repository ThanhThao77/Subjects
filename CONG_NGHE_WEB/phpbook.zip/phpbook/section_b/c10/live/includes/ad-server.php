<?php
class AdDisplayException extends Exception {};

// This file throws an exception
throw new AdDisplayException('Cannot load advert', 1);
?>