<?php include 'includes/header.php'; ?>
<h1>Sorry! An error occurred.</h1>
<p>The site owners have been informed. Please try again soon.</p>
<?php include 'includes/footer.php'; ?>