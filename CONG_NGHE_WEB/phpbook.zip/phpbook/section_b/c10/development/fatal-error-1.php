<?php
$price    = 7;
$quantity = 'five';
$total    = $price * $quantity;
?>
<h1>Basket</h1>
Total: $<?= $total ?>