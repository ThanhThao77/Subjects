Your error log is stored here: 
<?= ini_get('error_log') ?>