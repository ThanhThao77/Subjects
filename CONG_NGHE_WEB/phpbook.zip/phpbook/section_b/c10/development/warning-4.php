<?php $list = ['pencil', 'pen', 'notebook',]; ?>
<?= $list ?>