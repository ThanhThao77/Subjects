<?php include 'includes/header.php'; ?> 

<h1>Login</h1>
<b>You need to log in to view this page.</b>
<p>(You learn how to create a login system in Chapter 16.)</p>

<?php include 'includes/footer.php'; ?>