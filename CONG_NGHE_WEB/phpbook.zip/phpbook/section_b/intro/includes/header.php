<!DOCTYPE html>
<html>
  <head>
    <title>Section B Introduction Examples</title>
    <link href="css/styles.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Josefin+Slab|Raleway+Dots|Satisfy|Stardos+Stencil|Lato|Quicksand" rel="stylesheet">
    <meta encoding="UTF-8">
  </head>
  <body>
    <div class="page">
      <header>
        <a href="index.php"><img src="img/logo.png" alt="Mountain Art Supplies" height="90" /></a>
      </header>
      <section>